// Firebase init & helpers
