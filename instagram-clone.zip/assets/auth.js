// Authentication logic
