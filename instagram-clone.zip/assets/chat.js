// Chat logic
